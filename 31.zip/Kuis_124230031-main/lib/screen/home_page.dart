import 'package:flutter/material.dart';
import 'package:olah_data/screen/login_page.dart';
import 'package:olah_data/data/movie_data.dart';
import 'package:olah_data/screen/detail_page.dart';

class HomePage extends StatelessWidget {
  final String username;
  const HomePage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home Page"),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.person)),
          IconButton(
            onPressed: () {
              _logout(context);
            },
            icon: Icon(Icons.logout_outlined),
          ),
        ],
      ),
      body: Center(
        child: Column(
          children: [
            Text("Selamat Datang $username", style: TextStyle(fontSize: 16)),
            Text("Daftar Film:", style: TextStyle(fontSize: 25)),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16),
                    itemBuilder: (context, index){
                      return _movie(context, index);
                    },
                    itemCount: movieList.length,
                    ),
              )
            )
          ],
        ),
      ),
    );
  }

  void _logout(BuildContext context) {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) {
          return LoginPage();
        },
      ),
      (route) => false,
    );
  }
  Widget _movie(context, int index) {
  return InkWell(
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => DetailPage(movie: movieList[index]),
        ),
      );
    },
    child: Container(
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        border: Border.all(width: 2),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
    
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                movieList[index].imgUrl,
                fit: BoxFit.cover, 
                width: double.infinity,
              ),
            ),
          ),
          SizedBox(height: 6),
          Text(
            movieList[index].title,
            style: TextStyle(fontWeight: FontWeight.bold),
            overflow: TextOverflow.ellipsis,
          ),
          Text("Genre : ${movieList[index].genre}"),
          Text("Rating : ${movieList[index].rating}"),
          Text("Release Year : ${movieList[index].year}"),
          Icon(
            Icons.bookmark   
          )
        ],
      ),
    ),
  );
}
}